Demo length: 3–6 minutes

0:00–0:20 — Quick intro
- "Hello, I'm Aniket Thakur from [YourCollege]. This is my Fullstack Chat App built with Node/Express, React, MongoDB, Socket.IO and Cloudinary."

0:20–1:00 — Problem statement
- Explain problem: need for lightweight real-time messaging web app with multimedia support and simple deployment.

1:00–2:30 — Solution & architecture walkthrough
- Show ARCHITECTURE.md diagram and explain components: frontend (React/Vite), backend (Express + Socket.IO), DB (MongoDB Atlas), Cloudinary (images), hosting (optional).
- Explain data flow of a message send and receive.

2:30–4:30 — Live walkthrough (key features)
- Start app (briefly show backend and frontend running commands).
- Register a new user, set a profile picture (upload).
- Open second browser/incognito, log in as another user.
- Send text and image messages; show real-time appearance on both clients.
- Show message persistence (reload and show messages reloaded from DB).

4:30–5:00 — Additional features & trade-offs
- Briefly highlight security (JWT), file upload handling, CORS, limitations.

5:00–5:30 — What’s next / closing
- Roadmap bullets (scaling, tests, rooms, message search)
- Thank you / link to GitHub
