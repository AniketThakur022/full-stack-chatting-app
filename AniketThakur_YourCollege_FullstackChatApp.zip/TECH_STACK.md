# Tech Stack

**Frontend**
- React 18 (via Vite) — development server: Vite (v5.x recommended)
- Libraries: axios, react-router-dom, react-hot-toast, zustand (state), lucide-react, daisyUI/TailwindCSS

**Backend**
- Node.js (LTS 18 or 20)
- Express.js
- Socket.IO (server + client)
- Mongoose (MongoDB ODM)
- Multer or express-fileupload (for multipart handling) — if used in repo

**Database / Storage**
- MongoDB Atlas (cloud DB)
- Cloudinary (image hosting)

**Auth**
- JSON Web Tokens (JWT) — `jsonwebtoken` library

**Dev & Tools**
- npm / yarn
- nodemon (dev)
- Postman / curl (API testing)
- Git + GitHub

**Suggested versions**
- Node 18.x or 20.x
- npm 9.x
- Vite 5.x
- Mongoose 7.x
