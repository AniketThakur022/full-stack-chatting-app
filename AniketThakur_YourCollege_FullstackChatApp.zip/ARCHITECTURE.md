# Architecture & Data Flow

## ASCII Diagram (high-level)

[Client A - React/Vite]  <--websocket/socket.io-->  [Backend - Node/Express + Socket.IO]  <--->  [MongoDB Atlas]
        |                                                                    \
        |--(image upload via HTTP multipart)->  [Backend] -- (Cloudinary API)->  [Cloudinary Storage]

## Components
1. Frontend (React)
   - UI for login/register, chat UI, image pick/upload.
   - Sends messages via Socket.IO (real-time), sends file uploads to backend via HTTP POST (multipart).

2. Backend (Express)
   - REST endpoints: /api/auth (register/login), /api/messages (CRUD), /api/upload (image)
   - Socket.IO server: real-time messaging events (message:create -> broadcast on room/user)
   - Cloudinary integration: upload images and store returned URL in message document.
   - Auth middleware: JWT verification for protected routes and sockets.

3. MongoDB Atlas
   - Users collection: store user profile, avatar URL
   - Messages collection: store messages {sender, content, timestamp, imageUrl, readStatus}

4. Cloudinary
   - Stores images (user avatars or message attachments); returns secure CDN URL used in UI.

## Data flow example (send image message)
1. Client selects file → front-end posts file to `/api/upload` (multipart/form-data).
2. Backend receives file (multer), uploads to Cloudinary, obtains `secure_url`.
3. Backend creates message document in MongoDB with `imageUrl`.
4. Backend emits Socket.IO event (`newMessage`) to relevant clients.
5. Clients receive event and update UI in real time.
