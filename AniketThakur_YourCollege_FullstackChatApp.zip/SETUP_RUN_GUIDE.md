# Setup & Run (Development)

## Prerequisites
- Node.js v18+ or v20+
- npm (bundled)
- Git
- MongoDB Atlas account & cluster (or local MongoDB)
- Cloudinary account (for image uploads)
- Optional: pm2 for production

## 1) Clone repo
git clone https://github.com/burakorkmez/fullstack-chat-app.git
cd fullstack-chat-app

## 2) Backend: prepare .env
cd backend
# create .env with the variables in .env.example (replace placeholders)
# Example:
# MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxxx.mongodb.net/chat-app?retryWrites=true&w=majority
# PORT=5001
# JWT_SECRET=some_long_random_string
# CLOUDINARY_CLOUD_NAME=your_cloud_name
# CLOUDINARY_API_KEY=your_key
# CLOUDINARY_API_SECRET=your_secret
# NODE_ENV=development

npm install
# run
npm run dev
# nodemon should start server on PORT (default 5001)

## 3) Frontend
cd ../frontend
npm install
npm run dev
# Vite dev server typically runs at http://localhost:5173

## 4) Test
- Open http://localhost:5173
- Register a new user, upload avatar, open second browser to test real-time messaging.

# Production (build + serve with backend)
cd frontend
npm run build
cd ../backend
# Ensure backend serves the built frontend (code usually handles serving /frontend/dist)
NODE_ENV=production npm start
# Or use pm2:
pm2 start npm --name fullstack-chat -- start

# Troubleshooting
- If Mongo auth error: verify MONGODB_URI, whitelist your IP in Atlas Network Access
- If Cloudinary upload fails: verify cloud credentials in .env
- If Socket.IO connect fails: confirm backend is running and frontend socket points to correct backend origin
