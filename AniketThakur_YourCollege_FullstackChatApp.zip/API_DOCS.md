# Key API endpoints (based on repository)

## Auth
POST /api/auth/register
- Body: { name, email, password }
- Response: { user, token }

POST /api/auth/login
- Body: { email, password }
- Response: { user, token }

## Messages
GET /api/messages
- Query: optional pagination/search
- Response: list of message objects

POST /api/messages
- Body: { content, toUserId, imageUrl? }
- Protected: JWT
- Response: created message

## Upload (images)
POST /api/upload
- multipart/form-data, field: `image` (or `file`) — check repo code for exact field name
- Response: { url: "<cloudinary_url>" }

## Socket.IO events
- client -> server:
  - `message:send` { content, to, imageUrl? }
- server -> clients:
  - `message:new` { message }

## Sample message document
{
  _id: "...",
  sender: { _id, name, avatarUrl },
  receiverId: "...",
  content: "hello",
  imageUrl: "https://res.cloudinary.com/...",
  createdAt: ISODate,
  read: false
}
