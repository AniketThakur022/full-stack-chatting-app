# Suggested MongoDB Schemas (Mongoose-like)

## User
{
  _id: ObjectId,
  name: String,
  email: { type: String, unique: true },
  passwordHash: String,
  avatarUrl: String,
  createdAt: Date
}

## Message
{
  _id: ObjectId,
  senderId: ObjectId,
  receiverId: ObjectId, // or roomId for group chat
  content: String,
  imageUrl: String,
  createdAt: Date,
  read: Boolean
}
