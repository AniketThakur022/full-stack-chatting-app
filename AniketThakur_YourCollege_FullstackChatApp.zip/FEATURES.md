# Core Features Implemented

1. User registration & login (JWT)
   - Why: authentication is required to identify users.
   - Trade-offs: JWT short expiry vs refresh tokens not implemented (simpler).

2. Real-time messaging with Socket.IO
   - Why: low-latency message exchange.
   - Trade-offs: single server scaling is simple; for large scale need Redis adapter for Socket.IO.

3. Image upload for messages & avatars (Cloudinary)
   - Why: multimedia enhances chats and Cloudinary simplifies hosting.
   - Trade-offs: external dependency & free-tier limits.

4. Message persistence in MongoDB
   - Why: persist history and allow reloads.
   - Trade-offs: No full-text search implemented; simple indexes used.

5. Simple UI with React/Vite & Tailwind/daisyUI
   - Why: quick and responsive UI development.
   - Trade-offs: minimal advanced UX polish to meet submission deadline.

6. Basic security
   - Password hashing (bcrypt), JWT-based auth, CORS limited to frontend origin in dev.
