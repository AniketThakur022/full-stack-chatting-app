# Impact & Metrics

- Basic latency: end-to-end messaging latency (local) ~ <100ms (typical on local network) 
- DB write time (Mongo Atlas): ~10–30ms for simple message docs (depends on cluster tier)
- Concurrency assumptions: single server supports hundreds of concurrent socket connections before needing horizontal scaling (use Socket.IO Redis adapter to scale)
- Storage: Cloudinary handles image storage; free-tier limits apply (~25 credits/month). For higher volume use paid plan or S3.
