Use this folder for your submission. Replace placeholders (college name, demo video) before uploading to Drive.
