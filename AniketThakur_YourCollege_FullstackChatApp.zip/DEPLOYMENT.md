# Deployment Guide (one example: Render / Heroku / VPS)

## Option A – Render (recommended)
1. Create accounts (Render for server, Vercel for frontend or serve via backend)
2. Backend service: connect GitHub repo, set build command `npm install && npm run build:if_needed` then start command `npm start` (or use `node src/index.js`)
3. Add environment variables in Render console (the same keys as .env)
4. If serving frontend from backend: run frontend build step in build phase and ensure backend serves `frontend/dist`

## Option B – Vercel (frontend) + Render/Heroku (backend)
- Vercel for frontend: point to `frontend/`, use `npm run build` as build, `npm run preview` optional
- Backend: Render/Heroku. Set env vars in dashboard.

## Live URL:
- (Add your hosting live URL here once deployed)
