# What’s next / Known limitations

1. Scaling Socket.IO horizontally — add Redis adapter for multi-instance support.
2. Refresh token flow for JWTs and proper token revocation.
3. Add groups/rooms and message search.
4. Add end-to-end encryption for sensitive messages (optional).
5. Add unit/integration tests and CI pipeline.
6. Stronger rate limiting and abuse protection.
